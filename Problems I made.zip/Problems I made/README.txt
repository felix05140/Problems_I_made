﻿- 참고로 니가 다운로드한 zip 파일 보면 폴더 3개가 이름이 다 "ㅗ"로 똑같고 그냥 앞에만 로마 숫자 붙어있는데 폴더 이름 앞에 로마 숫자는 몇 챕터인지 표시하는 거임 (예시: II.ㅗ -> 챕터 2라는 뜻임)

- 그리고 "III. ㅗ" 이 폴더 열었을 때 "scripts" 폴더가 있을건데 그건 개발자가 문제 만들면서 기록 해둔거니깐 신경 안 써도됨 그리고 "Questions" 폴더가 PDF 문제들 있는 폴더니깐 열어서 잘 풀도록

- "ㅗ" 폴더랑 "II. ㅗ" 이 폴더들 열어서 확인했을 때 그 모서리쪽에 다 "Made by felix05140 :>"으로 적혀있는데 "felix05140"은 개발자 예전 아이디라서 저렇게 나온거임 참고로 개발자 현재 아이디는 "felix_fr4g1l3"로 나와있음

- Btw if u unzip da downloaded file, u will see 3 folders all named "ㅗ". Da Roman numerals in front of them show which chapter it is (4 example, "II.ㅗ" means Chapter 2). 

ㄴ Inside each folder, there r "scripts" and "Questions" folders: 

* U don't need 2 care about da "scripts" folder, as it's js 4 da developer's records.
* Pls open da "Questions" folder 2 find n solve da PDF problems

- Also u might see "Made by felix05140 :>" written in da corner of the folders. "felix05140" is js da developer's old username. Da current username is "felix_fr4g1l3"
